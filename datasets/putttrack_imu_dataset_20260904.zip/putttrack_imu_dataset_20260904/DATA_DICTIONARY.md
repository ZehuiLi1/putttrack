# 数据字典

所有原始文件是 JSON Lines：每行一个对象，按文件内顺序读取。

## `tag_motion`

- `sequence`：设备端运动样本序号；用于检测丢样和乱序。
- `source_monotonic_us`：设备单调时钟，微秒；同一 boot 内有效，不是 UTC。
- `host_received_ns`：主机收到或写出记录的时间戳；冻结历史批量读出时不能代表动作发生时间。
- `adxl367_accel_micro_ms2`：ADXL367 三轴加速度，单位 µm/s²；除以 1,000,000 得 m/s²。
- `bmi270_accel_micro_ms2`：BMI270 三轴加速度，单位 µm/s²。
- `bmi270_gyro_micro_rads`：BMI270 三轴角速度，单位 µrad/s；除以 1,000,000 得 rad/s。
- `adxl367_valid` / `bmi270_valid`：该样本传感器数据是否有效。
- `sensor_error_bits`：非零表示传感器错误。
- `episode_label` / `episode_notes`：采集时标签和操作者说明；仍需结合 MANIFEST 的质量注释。

## 其他记录

- `tag_status` / `tag_status_final`：设备、固件、传感器量程、功耗、电池和错误计数。
- `tag_episode_marker`：设备侧 GO/action-start 时间和序号。
- `tag_episode_window`：请求的 pre-roll 与 post-GO 窗口。
- `tag_frozen_history`：冻结历史快照元数据。
- `tag_capture_result`：连续性、身份和健康检查结果；PASS 只说明捕获完整，不证明动作标签正确。

## 坐标和物理解释

三轴值位于传感器/球体坐标系，不是固定场地坐标。球滚动或被手抓住时轴会旋转。加速度计测量比力：静止时模长约为 9.80665 m/s²；它不会直接输出位置或离地高度。若要估计“向上拿起”，需要用陀螺仪传播姿态，将加速度投影到场地竖直方向，并减去 1g。短时积分可以作为特征，不能当精确高度。
