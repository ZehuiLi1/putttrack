# PuttTrack IMU 全量研究数据包

生成日期：2026-09-04  
仓库提交：`bbe239b74ededfdff19466a57fe32160ab30fb04`

此压缩包包含当前工作区里找到的全部**唯一原始 Tag IMU 捕获**：161 个文件、113,867 条
`tag_motion` 样本。发现并去除了 2 份字节完全相同的重复副本。
另外有 21 个 JSONL 没有 `tag_motion` 记录（例如观察事件、运行审计或仅连接失败日志），不属于 IMU 原始数据，因此没有打包。

## 目录

- `01_early_firmware_and_motion_tests`：32 个文件
- `02_curated_stationary`：2 个文件
- `03_curated_manual_floor`：7 个文件
- `04_roller_preliminary`：9 个文件
- `05_roller_official`：86 个文件
- `06_field_pickup`：12 个文件
- `07_field_putt`：10 个文件
- `90_diagnostic_or_invalid`：3 个文件

- `MANIFEST.csv` / `MANIFEST.json`：逐文件标签、质量说明、采样统计、设备信息和校验值。
- `DATA_DICTIONARY.md`：JSONL 字段与单位。
- `MODEL_ANALYSIS_BRIEF_CN.md`：交给分析模型的任务、证据边界和当前拿起识别假设。
- `DUPLICATES.json`：被去重的原始路径。
- `SHA256SUMS.txt`：包内每个原始数据文件的 SHA-256。
- `documentation/`：仓库中已有的地面与滚轮研究说明。

## 使用原则

1. 原始 JSONL 未改写；一行是一个 JSON 对象。
2. 必须先看 `quality` 和 `quality_note_zh`，不要只信文件名或 `episode_label`。
3. `90_diagnostic_or_invalid` 不能作为监督训练真值。
4. 滚轮数据是受约束夹具数据，不能冒充真实推杆、自由滚动、撞击或拿起真值。
5. 训练/测试必须按完整会话、日期、机械版本或操作者分组，不能把同一连续动作的相邻窗口随机拆开。
6. 当前数据主要来自同一个球和操作者，适合特征探索，不足以声称产品准确率。

## 已知最新批次问题

- 最新 10 次 `pickup_carry` 全部有动作，但 r07 有 GO 前污染，r09 动作开始过晚，部分样本缺少完整静止尾段。
- 最新 10 次 `putt_normal` 中，r01–r04 疑似碰到障碍物；r05 全程静止；r06 时序/动作无效；r08 有 GO 前污染；r07/r09/r10 是目前最干净候选。
- 多次真实推杆使 BMI270 陀螺仪达到 ±2000 dps 量程边界；不要把削顶后的峰值当真实峰值。
- ADXL367 是低功耗唤醒哨兵，动态动作中常削顶；动态分类应优先使用 BMI270。
